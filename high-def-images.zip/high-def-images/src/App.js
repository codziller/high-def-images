import React from "react";
import "./scss/App.scss";
import LandingPage from "./screens/landingPage";
const App = () => {
  return (
    <div className="App">
      <LandingPage />
    </div>
  );
};

export default App;
